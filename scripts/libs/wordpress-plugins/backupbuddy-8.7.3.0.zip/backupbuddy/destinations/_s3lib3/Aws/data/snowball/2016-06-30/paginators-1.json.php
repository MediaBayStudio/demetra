<?php
// This file was auto-generated from sdk-root/src/data/snowball/2016-06-30/paginators-1.json
return [ 'pagination' => [ 'ListJobs' => [ 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'input_token' => 'NextToken', 'result_key' => 'JobListEntries', ], 'DescribeAddresses' => [ 'limit_key' => 'MaxResults', 'output_token' => 'NextToken', 'input_token' => 'NextToken', 'result_key' => 'Addresses', ], ],];
